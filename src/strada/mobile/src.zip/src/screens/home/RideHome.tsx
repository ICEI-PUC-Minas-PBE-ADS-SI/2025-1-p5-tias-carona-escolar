import React, { useCallback, useState } from "react";
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  FlatList,
  useWindowDimensions,
  ListRenderItemInfo,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useNavigation } from "@react-navigation/native";
import Icon from "react-native-vector-icons/MaterialIcons";
import CustomerCalendar from "./CalendarPopupView";
import FilterModal from "./FiltersModal";
import HotelListItem from "./ListItem";
import MyPressable from "@/src/components/MyPressable";
import { RIDE_LIST, RideListType } from "./model/ride_list_data";
import { lightTheme, Theme } from "@/src/constants/theme";
import { useRouter } from "expo-router";

const HALF_MONTHS = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "July",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];

const RideSharingScreen: React.FC = () => {
  const window = useWindowDimensions();
  const inset = useSafeAreaInsets();
  const navigation = useNavigation();
  const router = useRouter();
  const theme = lightTheme;
  const styles = getStyles(theme);

  const [startDate, setStartDate] = useState<Date>(new Date());
  const [endDate, setEndDate] = useState<Date>(() => {
    const date = new Date();
    date.setDate(date.getDate() + 5);
    return date;
  });
  const [showCal, setShowCal] = useState<boolean>(false);
  const [showFilter, setShowFilter] = useState<boolean>(false);

  const navigateToMap = useCallback(() => {
    router.push("/map/map");
  }, []);

  const contentHeader = (
    <View style={styles.searchHeaderContainer}>
      <View style={styles.searchBarContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Para onde você vai?"
          placeholderTextColor={`${theme.text}80`}
          selectionColor={theme.primary}
        />
        <View style={styles.searchBtnContainer}>
          <MyPressable
            style={styles.searchBtn}
            android_ripple={{
              color: theme.secondary,
              radius: 22,
              borderless: true,
            }}
            touchOpacity={0.6}
          >
            <Icon name="search" size={24} color={theme.background} />
          </MyPressable>
        </View>
      </View>
      <View style={styles.headerDetailContainer}>
        <MyPressable
          style={styles.headerSectionContainer}
          touchOpacity={0.6}
          onPress={() => setShowCal(true)}
        >
          <View style={styles.sectionIconContainer}>
            <Icon name="event" size={18} color={theme.primary} />
            <Text style={styles.headerDetailTitle}>Recorrência</Text>
          </View>
          {startDate == endDate ? (
            <Text style={styles.sectionText}>
              {`${String(startDate.getDate()).padStart(2, "0")}, ${
                HALF_MONTHS[startDate.getMonth()]
              }`}
            </Text>
          ) : (
            <Text style={styles.sectionText}>
              {`${String(startDate.getDate()).padStart(2, "0")}, ${
                HALF_MONTHS[startDate.getMonth()]
              } - ${String(endDate.getDate()).padStart(2, "0")}, ${
                HALF_MONTHS[endDate.getMonth()]
              }`}
            </Text>
          )}
        </MyPressable>
        <View style={styles.verticalDivider} />
        <View style={styles.headerSectionContainer}>
          <View style={styles.sectionIconContainer}>
            <Icon name="people" size={18} color={theme.primary} />
            <Text style={styles.headerDetailTitle}>Passageiros</Text>
          </View>
          <Text style={styles.sectionText}>1 pessoa</Text>
        </View>
      </View>
    </View>
  );

  const renderItem = useCallback(
    (data: ListRenderItemInfo<RideListType>) =>
      data.index > 0 ? (
        <HotelListItem {...{ data }} />
      ) : (
        <View style={styles.stickyHeaderContainer}>
          <Text style={styles.ridesCountText}>35 caronas disponíveis</Text>
          <View style={{ borderRadius: 4, overflow: "hidden" }}>
            <MyPressable
              style={styles.filterButton}
              onPress={() => setShowFilter(true)}
            >
              <Text style={styles.filterText}>Filtrar</Text>
              <Icon
                style={{ marginLeft: 4 }}
                name="tune"
                size={20}
                color={theme.primary}
              />
            </MyPressable>
          </View>
        </View>
      ),
    []
  );

  return (
    <>
      {/* Header */}
      <View
        style={[
          styles.header,
          { height: 48 + inset.top, paddingTop: inset.top },
        ]}
      >
        <View style={styles.headerLeft}>
          <MyPressable
            style={{ padding: 8 }}
            android_ripple={{
              color: theme.lightGrey,
              radius: 20,
              borderless: true,
            }}
            onPress={navigation.goBack}
          >
            <Icon name="arrow-back" size={22} color={theme.text} />
          </MyPressable>
        </View>
        <View
          style={{
            marginHorizontal: 16,
            maxWidth: window.width - 16 - 32 - 41 - 74, // 16, 32:- total padding/margin; 41, 74:- left and right view's width
          }}
        >
          <Text style={styles.headerTitle} numberOfLines={1}>
            Caronas
          </Text>
        </View>
        <View style={styles.headerRight}>
          <MyPressable
            style={{ padding: 8 }}
            android_ripple={{
              color: theme.lightGrey,
              radius: 20,
              borderless: true,
            }}
            onPress={() => {
              router.push("/chat/b27a796b-8256-4462-9baa-c360681b69d5");
            }}
          >
            <Icon name="favorite-border" size={22} color={theme.text} />
          </MyPressable>
          <MyPressable
            style={{ padding: 8 }}
            android_ripple={{
              color: theme.lightGrey,
              radius: 20,
              borderless: true,
            }}
            onPress={navigateToMap}
          >
            <Icon name="location-pin" size={22} color={theme.text} />
          </MyPressable>
        </View>
      </View>

      <View style={styles.container}>
        <FlatList
          contentContainerStyle={[styles.list, { paddingBottom: inset.bottom }]}
          stickyHeaderIndices={[1]}
          nestedScrollEnabled
          ListHeaderComponent={contentHeader}
          data={RIDE_LIST}
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
        />
      </View>

      <CustomerCalendar
        {...{ showCal, setShowCal }}
        minimumDate={new Date()}
        initialStartDate={startDate}
        initialEndDate={endDate}
        onApplyClick={(startData, endData) => {
          if (startData != null) {
            setStartDate(startData);
            if (endData == null) {
              setEndDate(startData);
            }
          }
          if (endData != null) {
            setEndDate(endData);
          }
        }}
      />
      <FilterModal {...{ showFilter, setShowFilter }} />
    </>
  );
};

const getStyles = (theme: Theme) =>
  StyleSheet.create({
    header: {
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: theme.background,
      paddingHorizontal: 8,
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: theme.lightGrey,
    },
    headerLeft: {
      alignItems: "flex-start",
      flexGrow: 1,
      flexBasis: 0,
    },
    headerTitle: {
      color: theme.text,
      fontSize: 20,
      fontFamily: "WorkSans-SemiBold",
      textAlign: "center",
    },
    headerRight: {
      flexDirection: "row",
      justifyContent: "flex-end",
      flexGrow: 1,
      flexBasis: 0,
    },
    container: {
      flex: 1,
      backgroundColor: theme.lightGrey,
    },
    list: {
      flexGrow: 1,
      backgroundColor: theme.background,
    },
    searchHeaderContainer: {
      backgroundColor: theme.background,
      paddingBottom: 12,
    },
    searchBarContainer: {
      flexDirection: "row",
      padding: 16,
      paddingBottom: 12,
    },
    searchInput: {
      flex: 1,
      backgroundColor: theme.background,
      borderRadius: 24,
      paddingHorizontal: 16,
      paddingVertical: 8,
      marginRight: 12,
      color: theme.text,
      fontSize: 16,
      elevation: 4,
      shadowColor: theme.lightGrey,
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.2,
      shadowRadius: 3,
      height: 44,
    },
    searchBtnContainer: {
      borderRadius: 28,
      elevation: 8,
      height: 44,
      width: 44,
    },
    searchBtn: {
      padding: 10,
      backgroundColor: theme.primary,
      borderRadius: 22,
      shadowColor: theme.secondary,
      shadowOffset: { width: 2, height: 2 },
      shadowOpacity: 0.2,
      shadowRadius: 8,
      height: 44,
      width: 44,
      alignItems: "center",
      justifyContent: "center",
    },
    headerDetailContainer: {
      flexDirection: "row",
      paddingHorizontal: 16,
      paddingBottom: 4,
    },
    sectionIconContainer: {
      flexDirection: "row",
      alignItems: "center",
      marginBottom: 4,
    },
    headerDetailTitle: {
      color: theme.text,
      fontSize: 14,
      marginLeft: 6,
      fontFamily: "WorkSans-Regular",
    },
    sectionText: {
      color: theme.text,
      fontSize: 15,
      fontFamily: "WorkSans-Medium",
    },
    verticalDivider: {
      width: 1,
      backgroundColor: `${theme.text}20`,
      marginRight: 12,
      marginVertical: 6,
    },
    headerSectionContainer: {
      flex: 1,
      paddingHorizontal: 6,
      paddingVertical: 2,
    },
    stickyHeaderContainer: {
      backgroundColor: theme.background,
      flexDirection: "row",
      paddingHorizontal: 16,
      paddingVertical: 12,
      borderBottomWidth: 1,
      borderBottomColor: theme.lightGrey,
      alignItems: "center",
    },
    ridesCountText: {
      flex: 1,
      color: theme.text,
      fontSize: 15,
      fontFamily: "WorkSans-Medium",
    },
    filterButton: {
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: theme.softPink,
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderRadius: 16,
    },
    filterText: {
      color: theme.darkPink,
      fontSize: 14,
      fontFamily: "WorkSans-Medium",
    },
  });

export default RideSharingScreen;
