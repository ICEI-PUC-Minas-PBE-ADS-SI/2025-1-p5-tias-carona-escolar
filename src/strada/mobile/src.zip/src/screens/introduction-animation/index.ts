export { default as IntroductionAnimationScreen } from './IntroductionAnimationScreen';
