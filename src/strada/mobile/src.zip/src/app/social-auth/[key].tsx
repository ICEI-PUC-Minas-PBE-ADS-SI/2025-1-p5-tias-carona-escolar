import SocialAuth from "@/src/screens/login/SocialAuth";
import React from "react";

const SocialAuthTab = () => {
  return <SocialAuth />;
};

export default SocialAuthTab;
