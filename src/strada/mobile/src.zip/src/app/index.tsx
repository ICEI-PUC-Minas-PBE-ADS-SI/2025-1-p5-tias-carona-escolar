import { SplashScreen } from "@/src/screens/splash";

export default function Index() {
  return <SplashScreen />;
}
