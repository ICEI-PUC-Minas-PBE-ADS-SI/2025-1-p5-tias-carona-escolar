import { ChatScreen } from "@/src/screens/chat";
import React from "react";

const ChatTab = () => {
  return <ChatScreen />;
};

export default ChatTab;
