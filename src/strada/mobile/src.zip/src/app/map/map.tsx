import MapboxMap from "@/src/screens/map/MapboxMap";
import React from "react";

const MapTab = () => {
  return <MapboxMap />;
};

export default MapTab;
