import { IntroductionAnimationScreen } from "@/src/screens/introduction-animation";

const GreetingsTab = () => {
  return <IntroductionAnimationScreen />;
};

export default GreetingsTab;
