export interface ICreadentials {
  username: string;
  password: string;
}